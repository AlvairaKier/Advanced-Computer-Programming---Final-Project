-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2024 at 09:18 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `keepsafe.db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `EmployeeID` int(11) NOT NULL,
  `EmplFirstname` varchar(100) NOT NULL,
  `EmplLastname` varchar(100) NOT NULL,
  `EmplUser` varchar(100) NOT NULL,
  `EmplPIN` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`EmployeeID`, `EmplFirstname`, `EmplLastname`, `EmplUser`, `EmplPIN`) VALUES
(1, 'Kier', 'Alvaira', 'kieradm', '1111'),
(2, 'Jherssle', 'Torrano', 'jherssadm', '2222'),
(3, 'Frank', 'Dela Torre', 'frankadm', '3333'),
(4, 'Jaspher', 'Malabanan', 'jasadm', '4444'),
(5, 'Carlo', 'Villalobos', 'carladm', '5555'),
(6, 'Arck', 'Torrano', 'arckadm', '6666'),
(7, 'Jeremi', 'Hall', 'Jadm', '7777'),
(8, 'Jehosh', 'Dimayuga', 'Jehoadm', '8888'),
(9, 'Jiro', 'Carag', 'Jiroadm', '9999'),
(10, 'Jayvee', 'Mayuga', 'jvadm', '1010');

-- --------------------------------------------------------

--
-- Table structure for table `deleted_user`
--

CREATE TABLE `deleted_user` (
  `DeletedUserID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Firstname` varchar(100) NOT NULL,
  `Lastname` varchar(100) NOT NULL,
  `Age` varchar(100) NOT NULL,
  `Username` char(4) NOT NULL,
  `PIN` varchar(100) NOT NULL,
  `DateofDeletion` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `deleted_user`
--

INSERT INTO `deleted_user` (`DeletedUserID`, `UserID`, `Firstname`, `Lastname`, `Age`, `Username`, `PIN`, `DateofDeletion`) VALUES
(1, 1, 'Jonathan', 'Smith', '21', 'Jdoe', '1000', '2024-11-22 22:23:33'),
(2, 2, 'Jherssle', 'Torrano', '19', 'Jher', '0002', '2024-11-25 21:10:45'),
(3, 3, 'John Kier', 'Alvaira', '20', 'Kier', '0506', '2024-11-25 21:11:22'),
(4, 4, 'Jane', 'Doe', '20', 'Jdoe', '0003', '2024-11-25 21:11:30'),
(5, 5, 'John Joseph', 'Alvaira', '18', 'Jjos', '0411', '2024-11-25 21:11:41'),
(6, 6, 'Wilma ', 'James', '35', 'wilm', '1001', '2024-11-25 21:11:50'),
(7, 7, 'Darwin', 'Alvaira', '50', 'DarA', '1011', '2024-11-25 21:11:58'),
(8, 8, 'Arcklynh', 'Mabelline', '18', 'arck', '1005', '2024-11-25 21:12:09'),
(9, 9, 'Ashton', 'Villalobos', '20', 'call', '3030', '2024-11-25 21:12:19'),
(10, 10, 'Frank', 'Dela Torre', '19', 'Fran', '9911', '2024-11-25 21:13:01'),
(12, 12, 'Frankin', 'Curry', '19', 'Fran', '0944', '2024-11-25 22:12:35');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `TransactionID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Amount` decimal(10,2) DEFAULT NULL,
  `FromBank` varchar(20) DEFAULT NULL,
  `ToBank` varchar(20) DEFAULT NULL,
  `TransactionDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `Status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`TransactionID`, `UserID`, `Amount`, `FromBank`, `ToBank`, `TransactionDate`, `Status`) VALUES
(1, 2, 500.00, 'Bank1_bal', 'Bank2_bal', '2024-11-22 09:48:50', 'Success'),
(2, 1, 3000.00, 'Bank 1', 'Bank 2', '2024-11-22 13:28:25', 'Success'),
(3, 3, 2500.00, 'Bank 1', 'Bank 2', '2024-11-22 14:05:34', 'Success'),
(4, 3, 500.00, 'Bank 1', 'Bank 2', '2024-11-22 14:53:10', 'Success'),
(5, 5, 1500.00, 'Bank 1', 'Bank 2', '2024-11-25 12:35:08', 'Success'),
(6, 5, 1500.00, 'Bank 1', 'Bank 2', '2024-11-25 12:35:20', 'Success'),
(7, 6, 5000.00, 'Bank 2', 'Bank 1', '2024-11-25 12:38:04', 'Success'),
(8, 7, 25000.00, 'Bank 2', 'Bank 1', '2024-11-25 12:40:00', 'Success'),
(9, 8, 550.00, 'Bank 1', 'Bank 2', '2024-11-25 12:46:08', 'Success'),
(10, 9, 740.00, 'Bank 2', 'Bank 1', '2024-11-25 12:51:45', 'Success'),
(11, 10, 1450.00, 'Bank 1', 'Bank 2', '2024-11-25 13:09:30', 'Success'),
(12, 13, 342.00, 'Bank 2', 'Bank 1', '2024-11-25 13:45:17', 'Success'),
(13, 14, 255.55, 'Bank 2', 'Bank 1', '2024-11-25 13:47:07', 'Success');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `Firstname` varchar(100) NOT NULL,
  `Lastname` varchar(100) NOT NULL,
  `Age` int(50) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `PIN` char(4) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `ContactNo` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Occupation` varchar(100) NOT NULL,
  `DateofCreation` datetime DEFAULT current_timestamp(),
  `Bank1_bal` decimal(10,2) NOT NULL,
  `Bank2_bal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `Firstname`, `Lastname`, `Age`, `Username`, `PIN`, `Address`, `ContactNo`, `Email`, `Occupation`, `DateofCreation`, `Bank1_bal`, `Bank2_bal`) VALUES
(13, 'Arckjher', 'Torrano', 19, 'Arckjher', '2004', 'Brgy, Bagong Pook Balisong Batangas', '09273716381', 'Arckjher@gmail.com', 'Student', '2024-11-25 21:45:02', 342.00, 4158.00),
(14, 'Paul', 'Roger', 18, 'Paul', '3004', 'Sta.Rosa Laguna', '09273736123', 'PaulRog@gmail.com', 'Driver', '2024-11-25 21:46:50', 255.55, 244.45),
(15, 'Gissle', 'Torrano', 35, 'GissleT', '0099', 'Brgy. Balisong Bagong pook Taal Batangas', '09784562342', 'Gissle123@gmail.com', 'Free Lancer', '2024-11-25 21:48:57', 2340.50, 35000.00),
(16, 'Aldrin', 'Uyquienco', 21, 'Aldrin', '1231', 'Manila, Philippines', '09757442362', 'AldrinUY@gmail.com', 'IT Professional', '2024-11-25 21:51:57', 3000.00, 70324.44),
(17, 'James', 'Dane', 32, 'Jdane', '0010', 'San Pablo, Laguna', '09554231322', 'JDane@gmail.com', 'Worker', '2024-11-25 21:52:58', 10.10, 1500.00),
(18, 'Sam', 'Sulek', 23, 'SamS', '0011', 'Florida USA', '09976554332', 'Sam.Sulek@gmail.com', 'Gym Coach', '2024-11-25 21:53:53', 3220.25, 3000.00),
(19, 'Arnold', 'Cacao', 35, 'Arnold', '0012', 'Balete, San Nicolas Batangas', '09776534567', 'ArnoldC@gmail.com', 'Vendor', '2024-11-25 21:55:03', 470.10, 2500.00),
(20, 'Jaspher Andrei', 'Malabanan', 19, 'JAMalabanan', '0023', 'Malinis Lemery Batangas', '09992332146', 'Jaspher.andrei@gmail.com', 'Student', '2024-11-25 21:58:38', 100.11, 43567.44),
(21, 'Frankin', 'Del Rosario', 20, 'FrankDR', '0021', 'Brgy. San Antonio, San Pablo Laguna', '09329934512', 'FrankDR', 'Worker', '2024-11-25 22:22:52', 34500.00, 0.00),
(22, 'Will', 'Smith', 45, 'WillS', '0043', 'Metro Manila Philippines', '09348559213', 'WillSmith@gmail.com', 'Worker', '2024-11-25 22:30:20', 3455.00, 55789.99);

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `after_user_delete` AFTER DELETE ON `users` FOR EACH ROW BEGIN
    INSERT INTO deleted_user (UserID, Firstname, Lastname, Age, Username, PIN)
    VALUES (OLD.UserID, OLD.Firstname, OLD.Lastname, OLD.Age, OLD.Username, OLD.PIN);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_updates`
--

CREATE TABLE `user_updates` (
  `UpdateID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `UpdatedField` enum('FirstName','LastName','Age','PIN','Address','ContactNo','Email','Occupation') NOT NULL,
  `OldValue` varchar(255) DEFAULT NULL,
  `NewValue` varchar(255) DEFAULT NULL,
  `UpdateDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_updates`
--

INSERT INTO `user_updates` (`UpdateID`, `UserID`, `UpdatedField`, `OldValue`, `NewValue`, `UpdateDate`) VALUES
(1, 1, 'FirstName', 'John', 'Jonathan', '2024-11-22 13:10:09'),
(2, 1, 'LastName', 'Doe', 'Smith', '2024-11-22 13:10:09'),
(3, 1, 'Age', '20', '21', '2024-11-22 13:10:09'),
(4, 1, 'PIN', '0001', '1000', '2024-11-22 13:10:09'),
(5, 1, 'Address', 'Califronia USA', 'California USA', '2024-11-22 13:10:09'),
(6, 1, 'ContactNo', '09150784813', '09275401854', '2024-11-22 13:10:09'),
(7, 1, 'Email', 'Johndoe@gmail.com', 'J.smith@gmail.com', '2024-11-22 13:10:09'),
(8, 3, 'FirstName', 'Kier', 'John Kier', '2024-11-22 14:22:37'),
(9, 3, 'Age', '19', '20', '2024-11-22 14:22:37'),
(10, 3, 'PIN', '0605', '0506', '2024-11-22 14:22:37'),
(11, 3, 'Address', 'Balete, San Nicolas Batangas', 'Kumintang Ilaya Batangas City', '2024-11-22 14:22:37'),
(12, 3, 'ContactNo', '09159784813', '09285472354', '2024-11-22 14:22:37'),
(13, 3, 'Email', 'kieralv@gmail.com', 'kierkier@gmail.com', '2024-11-22 14:22:37'),
(14, 5, 'Address', 'Los Angeles USA', 'Balete, San Nicolas Batangas', '2024-11-25 12:35:43'),
(15, 6, 'Occupation', 'Housewife', 'Online Seller', '2024-11-25 12:38:16'),
(16, 8, 'LastName', 'Torrano', 'Mabelline', '2024-11-25 12:46:49'),
(17, 8, 'Address', 'Brgy. Bagong Pook, Balisong Taal Batangas', 'Cainta, Rizal Philippines', '2024-11-25 12:46:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`EmployeeID`);

--
-- Indexes for table `deleted_user`
--
ALTER TABLE `deleted_user`
  ADD PRIMARY KEY (`DeletedUserID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`TransactionID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Username` (`Username`),
  ADD UNIQUE KEY `PIN` (`PIN`),
  ADD UNIQUE KEY `PIN_2` (`PIN`),
  ADD UNIQUE KEY `Username_2` (`Username`,`PIN`),
  ADD UNIQUE KEY `Firstname` (`Firstname`,`Lastname`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `user_updates`
--
ALTER TABLE `user_updates`
  ADD PRIMARY KEY (`UpdateID`),
  ADD KEY `UserID` (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `EmployeeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `deleted_user`
--
ALTER TABLE `deleted_user`
  MODIFY `DeletedUserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `TransactionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `user_updates`
--
ALTER TABLE `user_updates`
  MODIFY `UpdateID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `user_updates`
--
ALTER TABLE `user_updates`
  ADD CONSTRAINT `user_updates_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
